﻿Public Class Form1
    Private Sub Img_foto_Click(sender As Object, e As EventArgs) Handles img_foto.Click
        Try
            With OpenFileDialog1
                .Title = "Selecione uma Foto"
                .InitialDirectory = Application.StartupPath & "\Fotos\"
                .ShowDialog()
                diretorio = .FileName
                img_foto.Load(diretorio)
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conecta_banco()
        Carregar_dados()

    End Sub

    Private Sub Btn_gravar_Click(sender As Object, e As EventArgs) Handles btn_gravar.Click
        Try
            sql = $"select * from tb_cadastro where cpf='{txt_cpf.Text}'"

            rs = db.Execute(sql)
            If rs.EOF = True Then 'se não existir o CPF na tabela'
                sql = $"insert into tb_cadastro (cpf,nome,data_nasc,fone,email,foto)
                values ('{txt_cpf.Text}','{txt_nome.Text}','{cmb_data.Value.ToShortDateString}','{txt_fone.Text}','{txt_email.Text}','{diretorio}');"
                rs = db.Execute(UCase(sql))
                MsgBox("Cliente Cadastrado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                Limpar_Cadastro()
                Carregar_dados()

            Else
                MsgBox("Cliente já Cadastrado!", MsgBoxStyle.Exclamation + MsgBoxStyle.OkOnly, "AVISO")
                txt_cpf.Focus()
            End If


        Catch ex As Exception
            MsgBox($"Erro ao Gravar!: '{ex.Message}'", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
    Private Sub Txt_cpf_LostFocus(sender As Object, e As EventArgs) Handles txt_cpf.LostFocus
        Try
            sql = $"select * from tb_cadastro where cpf ='{txt_cpf.Text}'"
            rs = db.Execute(sql)
            If rs.EOF = False Then
                txt_nome.Text = rs.Fields(2).Value
                cmb_data.Value = rs.Fields(3).Value
                txt_fone.Text = rs.Fields(4).Value
                txt_email.Text = rs.Fields(5).Value
                img_foto.Load(rs.Fields(6).Value)
            End If
        Catch ex As Exception
            MsgBox($"Erro ao Consultar!: '{ex.Message}'", MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub
End Class
