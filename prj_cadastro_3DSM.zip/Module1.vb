﻿Module Module1
    Public db As New ADODB.Connection 'Variável do Banco
    Public rs As New ADODB.Recordset 'Variável da Tabela
    Public sql, diretorio As String
    Public cont As Integer

    Sub Carregar_dados()
        Try
            With Form1.dgv_dados
                sql = $"select * from tb_cadastro order by nome asc"
                rs = db.Execute(sql)
                cont = 0
                .Rows.Clear()
                Do While rs.EOF = False
                    cont += 1
                    .Rows.Add(cont, rs.Fields(1).Value, rs.Fields(2).Value, Nothing, Nothing)
                    rs.MoveNext()
                Loop
            End With
        Catch ex As Exception
            MsgBox($"Erro ao carregar!: {ex.Message}", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly)
        End Try
    End Sub

    Sub Conecta_banco()
        Try
            db = CreateObject("ADODB.Connection")
            db.Open("Provider=SQLOLEDB;Data Source=LAB5-21;Initial Catalog=cad_3dsm26;trusted_connection=yes;")
            MsgBox("Conexão OK", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")

        Catch ex As Exception
            MsgBox($"Erro ao conectar!: {ex.Message}", MsgBoxStyle.Critical + MsgBoxStyle.OkOnly, "ATENÇÃO")
        End Try
    End Sub
    Sub Limpar_Cadastro()
        Try
            With Form1
                .txt_cpf.Clear()
                .txt_nome.Clear()
                .cmb_data.Value = Now
                .txt_fone.Clear()
                .txt_email.Clear()
                .img_foto.Load(Application.StartupPath & "\Fotos\nova_foto.png")
                .txt_cpf.Focus()
            End With
        Catch ex As Exception
            Exit Sub
        End Try
    End Sub
End Module
